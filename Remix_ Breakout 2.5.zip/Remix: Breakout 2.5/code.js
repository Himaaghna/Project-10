var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a9df25fa-4ccf-43bf-b8a0-8b5fec3cf798","27a22136-d3ef-407f-928e-4b6a9f627d63","1ef9bfbf-7a57-44e5-baed-2a4b71ad2dc6","e282e040-27f3-4421-9dc7-1b6010042ffb","ed894e0c-2012-492b-91e3-f4de1b6e3130","14f1eead-3c3c-4daa-a411-fdbc1af06b88","1e7517f6-526c-43c5-9635-9910d1f1dde6","70a932b2-d465-4200-be74-5587930a2c75","a4a7c123-e2d6-49c0-9293-4df54cb9e0b2","cefb2e22-16ed-4baa-9114-50cf7edfbf5c","07e10b09-062c-4d97-aaef-633fff6659b2","4964f20a-8406-4055-bd5e-64157c3511c1","3f7596c5-5d1e-41a8-bddd-25fddb4ff907","09db920b-ebdc-489c-939c-9f7f9de8f315","2253fd34-5138-47f3-a835-4a6a448ccca9","e8c9fe0a-6dc5-4a95-b75e-0bd9e84e784f","a7231861-d5ce-4cee-8781-169791c15b97","0ae6b754-36c6-411c-870e-97dde0f9c41b","8f90c20c-a329-4c56-ac47-e7f3b47864b8","fdc72cb5-00fe-435d-a87a-95ea6e4b04a7","64b463dd-b156-4c90-8427-65abb651fc97","b40df702-ea07-4c0d-8dc7-5bf924371308"],"propsByKey":{"a9df25fa-4ccf-43bf-b8a0-8b5fec3cf798":{"name":"virus03_03_1","sourceUrl":"assets/api/v1/animation-library/gamelab/KoZz0QksHdpzqfX71bq5vgJR__O0e4sP/category_germs/virus03_03.png","frameSize":{"x":388,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"KoZz0QksHdpzqfX71bq5vgJR__O0e4sP","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/KoZz0QksHdpzqfX71bq5vgJR__O0e4sP/category_germs/virus03_03.png"},"27a22136-d3ef-407f-928e-4b6a9f627d63":{"name":"gameplaywacky_13_1","sourceUrl":"assets/api/v1/animation-library/gamelab/NYXAKV8lMtBFQ4CvUgBDjrGq5xJ8.AMN/category_germs/gameplaywacky_13.png","frameSize":{"x":400,"y":398},"frameCount":1,"looping":true,"frameDelay":2,"version":"NYXAKV8lMtBFQ4CvUgBDjrGq5xJ8.AMN","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":398},"rootRelativePath":"assets/api/v1/animation-library/gamelab/NYXAKV8lMtBFQ4CvUgBDjrGq5xJ8.AMN/category_germs/gameplaywacky_13.png"},"1ef9bfbf-7a57-44e5-baed-2a4b71ad2dc6":{"name":"gameplaywacky_05_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ZdtNFtOiydwR9zKYWovoGTaaRFuvBF6p/category_germs/gameplaywacky_05.png","frameSize":{"x":397,"y":372},"frameCount":1,"looping":true,"frameDelay":2,"version":"ZdtNFtOiydwR9zKYWovoGTaaRFuvBF6p","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":397,"y":372},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ZdtNFtOiydwR9zKYWovoGTaaRFuvBF6p/category_germs/gameplaywacky_05.png"},"e282e040-27f3-4421-9dc7-1b6010042ffb":{"name":"gameplaywacky_02_1","sourceUrl":"assets/api/v1/animation-library/gamelab/FGd.xwvKrpdqQks6CQstgdotKRmQc3_y/category_germs/gameplaywacky_02.png","frameSize":{"x":397,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"FGd.xwvKrpdqQks6CQstgdotKRmQc3_y","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":397,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/FGd.xwvKrpdqQks6CQstgdotKRmQc3_y/category_germs/gameplaywacky_02.png"},"ed894e0c-2012-492b-91e3-f4de1b6e3130":{"name":"gameplaywacky_17_1","sourceUrl":"assets/api/v1/animation-library/gamelab/MWHsgJ9QlyBJpBrb33SXuX04efW1trjy/category_germs/gameplaywacky_17.png","frameSize":{"x":399,"y":393},"frameCount":1,"looping":true,"frameDelay":2,"version":"MWHsgJ9QlyBJpBrb33SXuX04efW1trjy","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":399,"y":393},"rootRelativePath":"assets/api/v1/animation-library/gamelab/MWHsgJ9QlyBJpBrb33SXuX04efW1trjy/category_germs/gameplaywacky_17.png"},"14f1eead-3c3c-4daa-a411-fdbc1af06b88":{"name":"gameplaywacky_18_1","sourceUrl":"assets/api/v1/animation-library/gamelab/XPV2K6ikOfhF.2Jek87gD9AAVCmeN53r/category_germs/gameplaywacky_18.png","frameSize":{"x":400,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"XPV2K6ikOfhF.2Jek87gD9AAVCmeN53r","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/XPV2K6ikOfhF.2Jek87gD9AAVCmeN53r/category_germs/gameplaywacky_18.png"},"1e7517f6-526c-43c5-9635-9910d1f1dde6":{"name":"gameplaywacky_15_1","sourceUrl":"assets/api/v1/animation-library/gamelab/YZnVYfhRtgoSwdRGqlS24uEVuKwHbe4t/category_germs/gameplaywacky_15.png","frameSize":{"x":400,"y":395},"frameCount":1,"looping":true,"frameDelay":2,"version":"YZnVYfhRtgoSwdRGqlS24uEVuKwHbe4t","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":395},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YZnVYfhRtgoSwdRGqlS24uEVuKwHbe4t/category_germs/gameplaywacky_15.png"},"70a932b2-d465-4200-be74-5587930a2c75":{"name":"virus03_08_1","sourceUrl":"assets/api/v1/animation-library/gamelab/84glPGNWF96yVw37ubRFQIYuIQYx80S4/category_germs/virus03_08.png","frameSize":{"x":388,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"84glPGNWF96yVw37ubRFQIYuIQYx80S4","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/84glPGNWF96yVw37ubRFQIYuIQYx80S4/category_germs/virus03_08.png"},"a4a7c123-e2d6-49c0-9293-4df54cb9e0b2":{"name":"emoji_26_1","sourceUrl":"assets/api/v1/animation-library/gamelab/GMAQuYTBESkvMxOSLy7vYpmZjN.0s9Za/category_emoji/emoji_26.png","frameSize":{"x":340,"y":312},"frameCount":1,"looping":true,"frameDelay":2,"version":"GMAQuYTBESkvMxOSLy7vYpmZjN.0s9Za","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":340,"y":312},"rootRelativePath":"assets/api/v1/animation-library/gamelab/GMAQuYTBESkvMxOSLy7vYpmZjN.0s9Za/category_emoji/emoji_26.png"},"cefb2e22-16ed-4baa-9114-50cf7edfbf5c":{"name":"emoji_28_1","sourceUrl":"assets/api/v1/animation-library/gamelab/vwCBOAiepr3mzulfgNabixoXrB4o4M70/category_emoji/emoji_28.png","frameSize":{"x":340,"y":312},"frameCount":1,"looping":true,"frameDelay":2,"version":"vwCBOAiepr3mzulfgNabixoXrB4o4M70","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":340,"y":312},"rootRelativePath":"assets/api/v1/animation-library/gamelab/vwCBOAiepr3mzulfgNabixoXrB4o4M70/category_emoji/emoji_28.png"},"07e10b09-062c-4d97-aaef-633fff6659b2":{"name":"halloweenemoji_02_1","sourceUrl":"assets/api/v1/animation-library/gamelab/zmYdYuZAh.JJ6ip_l8UpgmdoY1j0Ujyy/category_emoji/halloweenemoji_02.png","frameSize":{"x":392,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"zmYdYuZAh.JJ6ip_l8UpgmdoY1j0Ujyy","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":392,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/zmYdYuZAh.JJ6ip_l8UpgmdoY1j0Ujyy/category_emoji/halloweenemoji_02.png"},"4964f20a-8406-4055-bd5e-64157c3511c1":{"name":"emoji_27_1","sourceUrl":"assets/api/v1/animation-library/gamelab/UL25W_73xH.9rkaveazuNDGGwhUtLHLj/category_emoji/emoji_27.png","frameSize":{"x":300,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"UL25W_73xH.9rkaveazuNDGGwhUtLHLj","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/UL25W_73xH.9rkaveazuNDGGwhUtLHLj/category_emoji/emoji_27.png"},"3f7596c5-5d1e-41a8-bddd-25fddb4ff907":{"name":"halloweenemoji_06_1","sourceUrl":"assets/api/v1/animation-library/gamelab/5xtqA.QL.u4oYCh3UMHCBcFczTvjBeQl/category_emoji/halloweenemoji_06.png","frameSize":{"x":356,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"5xtqA.QL.u4oYCh3UMHCBcFczTvjBeQl","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":356,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/5xtqA.QL.u4oYCh3UMHCBcFczTvjBeQl/category_emoji/halloweenemoji_06.png"},"09db920b-ebdc-489c-939c-9f7f9de8f315":{"name":"halloweenemoji_13_1","sourceUrl":"assets/api/v1/animation-library/gamelab/VIEfY9VleJEGrsqBNUezjosY_BBXwola/category_emoji/halloweenemoji_13.png","frameSize":{"x":352,"y":324},"frameCount":1,"looping":true,"frameDelay":2,"version":"VIEfY9VleJEGrsqBNUezjosY_BBXwola","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":352,"y":324},"rootRelativePath":"assets/api/v1/animation-library/gamelab/VIEfY9VleJEGrsqBNUezjosY_BBXwola/category_emoji/halloweenemoji_13.png"},"2253fd34-5138-47f3-a835-4a6a448ccca9":{"name":"gameplayadventure_11_1","sourceUrl":"assets/api/v1/animation-library/gamelab/GSiC57fZPi3yBvLh1A6eKX_U1e7Gt.rb/category_fantasy/gameplayadventure_11.png","frameSize":{"x":327,"y":389},"frameCount":1,"looping":true,"frameDelay":2,"version":"GSiC57fZPi3yBvLh1A6eKX_U1e7Gt.rb","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":327,"y":389},"rootRelativePath":"assets/api/v1/animation-library/gamelab/GSiC57fZPi3yBvLh1A6eKX_U1e7Gt.rb/category_fantasy/gameplayadventure_11.png"},"e8c9fe0a-6dc5-4a95-b75e-0bd9e84e784f":{"name":"halloweenemoji_18_1","sourceUrl":"assets/api/v1/animation-library/gamelab/gRRypFLmc1bH.C1.ZIY1aMNN_dyN4wxJ/category_emoji/halloweenemoji_18.png","frameSize":{"x":396,"y":356},"frameCount":1,"looping":true,"frameDelay":2,"version":"gRRypFLmc1bH.C1.ZIY1aMNN_dyN4wxJ","categories":["emoji"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":356},"rootRelativePath":"assets/api/v1/animation-library/gamelab/gRRypFLmc1bH.C1.ZIY1aMNN_dyN4wxJ/category_emoji/halloweenemoji_18.png"},"a7231861-d5ce-4cee-8781-169791c15b97":{"name":"ground_cake_1","sourceUrl":null,"frameSize":{"x":380,"y":94},"frameCount":1,"looping":true,"frameDelay":12,"version":"xwMZo5wLgYhnMPFiNQVqS34jXzWVcbGR","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":380,"y":94},"rootRelativePath":"assets/a7231861-d5ce-4cee-8781-169791c15b97.png"},"0ae6b754-36c6-411c-870e-97dde0f9c41b":{"name":"puck_1","sourceUrl":"assets/api/v1/animation-library/gamelab/wcuV7DcPEac2EjLNAPemwiDn.zqV1cHa/category_sports/puck.png","frameSize":{"x":393,"y":243},"frameCount":1,"looping":true,"frameDelay":2,"version":"wcuV7DcPEac2EjLNAPemwiDn.zqV1cHa","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":243},"rootRelativePath":"assets/api/v1/animation-library/gamelab/wcuV7DcPEac2EjLNAPemwiDn.zqV1cHa/category_sports/puck.png"},"8f90c20c-a329-4c56-ac47-e7f3b47864b8":{"name":"space_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"},"fdc72cb5-00fe-435d-a87a-95ea6e4b04a7":{"name":"cave_1","sourceUrl":"assets/api/v1/animation-library/gamelab/In3iY920nuOrZ0JmAOQbuVG8j8D4iTGD/category_backgrounds/background_cave.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"In3iY920nuOrZ0JmAOQbuVG8j8D4iTGD","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/In3iY920nuOrZ0JmAOQbuVG8j8D4iTGD/category_backgrounds/background_cave.png"},"64b463dd-b156-4c90-8427-65abb651fc97":{"name":"golfball_1","sourceUrl":"assets/api/v1/animation-library/gamelab/HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY/category_sports/golfball.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/HnGkChZ0Lf5fTeAmaQDwhmGSUiF59YcY/category_sports/golfball.png"},"b40df702-ea07-4c0d-8dc7-5bf924371308":{"name":"basketball_1","sourceUrl":"assets/api/v1/animation-library/gamelab/gidpYsDCQ6vgtpIhHHB9XL7sDgLB0j9U/category_icons/basketball.png","frameSize":{"x":391,"y":391},"frameCount":1,"looping":true,"frameDelay":2,"version":"gidpYsDCQ6vgtpIhHHB9XL7sDgLB0j9U","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":391,"y":391},"rootRelativePath":"assets/api/v1/animation-library/gamelab/gidpYsDCQ6vgtpIhHHB9XL7sDgLB0j9U/category_icons/basketball.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating plddle and the ball
var BG = createSprite(200, 200,400,400);
BG.setAnimation("space_1");

var paddle = createSprite(200, 375, 50, 15);
paddle.setAnimation("ground_cake_1");
paddle.scale=0.3;
var ball = createSprite(200, 200, 20, 20);
ball.setAnimation("basketball_1");
ball.scale=0.07;

var score=0;
var gameState ="serve";

//first row of boxes
var box1 = createSprite(25, 75, 50, 50);
box1.setAnimation("virus03_03_1");
box1.scale=0.12;
var box2 = createSprite(75, 75, 50, 50);
box2.setAnimation("gameplaywacky_13_1");
box2.scale=0.14;

var box3 = createSprite(125, 75, 50, 50);
box3.setAnimation("gameplaywacky_05_1");
box3.scale=0.13;
var box4 = createSprite(175, 75, 50, 50);
box4.setAnimation("gameplaywacky_02_1");
box4.scale=0.15;
var box5 = createSprite(225, 75, 50, 50);
box5.setAnimation("gameplaywacky_17_1");
box5.scale=0.12;
var box6 = createSprite(275, 75, 50, 50);
box6.setAnimation("gameplaywacky_18_1");
box6.scale=0.14;
var box7 = createSprite(325, 75, 50, 50);
box7.setAnimation("gameplaywacky_15_1");
box7.scale=0.14;
var box8 = createSprite(375, 75, 50, 50);
box8.setAnimation("virus03_08_1");
box8.scale=0.13;

//second row of boxes
var box9 = createSprite(25, 125, 50, 50);
box9.setAnimation("emoji_26_1");
box9.scale=0.12;
var box10 = createSprite(75, 125, 50, 50);
box10.setAnimation("emoji_28_1");
box10.scale=0.12;
var box11 = createSprite(125, 125, 50, 50);
box11.setAnimation("halloweenemoji_02_1");
box11.scale=0.12;
var box12 = createSprite(175, 125, 50, 50);
box12.setAnimation("emoji_27_1");
box12.scale=0.12;
var box13 = createSprite(225, 125, 50, 50);
box13.setAnimation("halloweenemoji_06_1");
box13.scale=0.12;
var box14 = createSprite(275, 125, 50, 50);
box14.setAnimation("halloweenemoji_13_1");
box14.scale=0.12;
var box15 = createSprite(325, 125, 50, 50);
box15.setAnimation("gameplayadventure_11_1");
box15.scale=0.12;
var box16 = createSprite(375, 125, 50, 50);
box16.setAnimation("halloweenemoji_18_1");
box16.scale=0.12;


function draw() {
  drawSprites();
  
  //display score
  fill("white");
  textFont("Viner Hand ITC");
  textSize(20);
  text("Score :"+score,295,25);
  
  if(gameState == "serve")
  {
   //display welcome text
    textSize(17);
    text("Welcome! Press space to start.",70,250);
    text("Move The Mouse To Move The Paddle.",60,280);
    text("Objective To Reach-16 ",100,320); 
    
  //Moving the ball on pressing enter key
  if(keyDown("space")){
    ball.velocityX = -4;
    ball.velocityY = 4;
    gameState="play";
  } 
  }
  
  if(gameState == "play")
  {
   //Making the ball bounceOff the paddle and three sides of canvas
  createEdgeSprites();
  ball.bounceOff(rightEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(topEdge);
  ball.bounceOff(paddle);

  //Moving the paddle with mouse along the x-axis
  paddle.x=World.mouseX;
  
  //destroy the boxes when ball touches them
  if(ball.isTouching(box1))
  {
    score=score+1;
    box1.destroy();
  }
  
  if(ball.isTouching(box2))
  {
    score=score+1;
    box2.destroy();
  }
  
  if(ball.isTouching(box3))
  {
    score=score+1;
    box3.destroy();
  }
  
  if(ball.isTouching(box4))
  {
    score=score+1;
    box4.destroy();
  }
  
  if(ball.isTouching(box5))
  {
    score=score+1;
    box5.destroy();
  }
  
  if(ball.isTouching(box6))
  {
    score=score+1;
    box6.destroy();
  }
  
  if(ball.isTouching(box7))
  {
    score=score+1;
    box7.destroy();
  }
  
  if(ball.isTouching(box8))
  {
    score=score+1;
    box8.destroy();
  }
  
  if(ball.isTouching(box9))
  {
    score=score+1;
    box9.destroy();
  }
  
  if(ball.isTouching(box10))
  {
    score=score+1;
    box10.destroy();
  }
  if(ball.isTouching(box11))
  {
    score=score+1;
    box11.destroy();
  }
  if(ball.isTouching(box12))
  {
    score=score+1;
    box12.destroy();
  }
  if(ball.isTouching(box13))
  {
    score=score+1;
    box13.destroy();
  }
  if(ball.isTouching(box14))
  {
    score=score+1;
    box14.destroy();
  }
  if(ball.isTouching(box15))
  {
    score=score+1;
    box15.destroy();
  }
  if(ball.isTouching(box16))
  {
    score=score+1;
    box16.destroy();
  }
  if (score==16||ball.isTouching(bottomEdge)) {
   gameState="end"; 
  }
  
  
  }
  
  if(gameState == "end")
  {
    textFont("Algerian");
   text("GAME OVER!! ",100,200);
   text("Your Score Is- "+score,100,250); 
  
  }

  

}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
